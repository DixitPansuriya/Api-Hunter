import React, { useEffect, useState } from 'react'
import axios from 'axios'


export default function Axios() {
    const [state, setState] = useState("")
    const [todo, setTodo] = useState([])

    useEffect(() => {
        fetch()
    }, [])
    async function fetch() {
        try {
            const response =await axios.get("http://localhost:3000/todo")
            setTodo(response.data)
        } catch (error) {
            console.log(error)
        }
    }
    function addText(e) {
        setState(e.target.value)
    }
    async function addTodo() {
        try {
            const response = await axios.post("http://localhost:3000/todo", { name  : state })
            setTodo([...todo,response.data])

        } catch (error) {
            console.log(error)
        }
    }
        async function Delete(id){
          try{
           await axios.delete(`http://localhost:3000/todo/${id}`)
           setTodo(todo.filter(x=> x.id !== id))

            
          } catch(error){
            console.log(error)
          }
       }
          
    return (
        <div>
            
            <input type="text" onChange={addText} />
            <button onClick={addTodo}>click</button>
                  <p>

                {todo.map((el,i) => {
                    return <li>{el.name}
                    <button onClick={Delete(el.id)}>Delete</button>
                    </li>
                    })}
           
                </p>
        </div>
    )
}
