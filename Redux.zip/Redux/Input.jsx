import React, { useState } from 'react'

export default function Input() {

    const [state,setState] = useState('')

    function addtext(e) {
        setState(e.target.value)
        
    }
    function add() {
        
    }
  return (
    <div>
      <input type="text" onChange={addtext} />
      <button onClick={add}>click</button>
    </div>
  )
}
